package aspects;


public interface Subject {
	
}
